package Sesi_4;

public class latihan4 {
    public static void main(String[] args) {
        int a = 10;
        int b = 8;
        int c = 12;
        int d = 5;

        //Tes Perbandingan
        System.out.println("Tes ke 1 = " + (a>b)); //tes perbandingan operator >
        System.out.println("Tes ke 2 = " + (b<c)); //tes perbandingan operator <
        System.out.println("Tes ke 3 = " + (b>=d)); //tes perbandingan operator >=
        System.out.println("Tes ke 4 = " + (a<=c)); //tes perbandingan operator <=
        System.out.println("Tes ke 5 = " + (d==5)); //tes perbandingan operator ==
        System.out.println("Tes ke 6 = " + (a!=b)); //tes perbandingan operator !=
        System.out.println("Tes ke 7 = " + (b>c)); //tes perbandingan operator >
        System.out.println("Tes ke 8 = " + (a<=b)); //tes perbandingan operator <=
        System.out.println("Tes ke 9 = " + (c==8)); //tes perbandingan operator ==
        System.out.println("Tes ke 10 = " + (b!=8)); //tes perbandingan operator !=
    }
}
