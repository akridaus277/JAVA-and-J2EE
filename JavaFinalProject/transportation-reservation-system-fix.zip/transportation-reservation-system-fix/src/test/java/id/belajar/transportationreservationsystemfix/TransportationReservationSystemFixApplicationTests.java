package id.belajar.transportationreservationsystemfix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransportationReservationSystemFixApplicationTests {

	@Test
	void contextLoads() {
	}

}
